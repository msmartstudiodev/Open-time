export default function handler(request, response) {
  const currentTime = new Date();

  // সরাসরি JSON রেসপন্স পাঠানো হয়
  response.status(200).json({
    time: currentTime.toISOString(),
    timezone: 'UTC',
  });
}